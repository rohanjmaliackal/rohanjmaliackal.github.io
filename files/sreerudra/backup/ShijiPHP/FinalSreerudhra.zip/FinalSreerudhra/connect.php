<?php
//$con=mysqli_connect("localhost","anzevent","anzevent","anzevent");
$con=mysqli_connect("localhost","sreerudhradb","sreerudhradb","sreerudhradb");

?>