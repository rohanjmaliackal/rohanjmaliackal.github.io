<?php
require_once("connect.php");
$booking_id=$_GET['booking_id'];
mysqli_query($con,"update booking set status='1',stat='admin',st='cancelled' where booking_id='".$booking_id."'");
//mysqli_query($con,"update tocken set status='free' where booking_id='".$booking_id."'");

$email=$_GET['email'];
$admin_email=$_GET['email'];
    	
					$name=$fname."&nbsp;".$lname;
					$email = "shiji.sienti@gmail.com";
					$subject="Booking Rejected";
					$date=date("Y-m-d");
					$dates = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
					$time=$dates->format('H:i:s a');
					//$message='You are invited by Shiji to join D4Designers';
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
					$headers .= 'From: '.$email."\r\n".
					'Reply-To: '.$email."\r\n" .
					'X-Mailer: PHP/' . phpversion();
					$mail='MIME-Version: 1.0' . "\r\n";
					$message='<html><head><style>
						body {
							font-family: -apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
							font-size: 1rem;
							font-weight: 400;
							line-height: 1.5;
							color: #292b2c;
							background-color: #fff;
						}
						.bd-example::after {
							display: block;
							content: "";
							clear: both;
						}
						.bd-example {
							padding: 1.5rem;
							margin-right: 0;
							margin-bottom: 0;
							margin-left: 0;
							border-width: .2rem;
						}
						.bd-example {
							position: relative;
							padding: 1rem;
							margin: 1rem -1rem;
							border: solid #f7f7f9;
							border-width: .2rem 0 0;
						}
						.text-center {
							text-align: center!important;
						}
						.card {
							position: relative;
							display: -webkit-box;
							display: -webkit-flex;
							display: -ms-flexbox;
							display: flex;
							-webkit-box-orient: vertical;
							-webkit-box-direction: normal;
							-webkit-flex-direction: column;
							-ms-flex-direction: column;
							flex-direction: column;
							background-color: #fff;
							border: 1px solid rgba(0,0,0,.125);
							border-radius: .25rem;
						}
						.card-header:first-child {
							border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;
						}
						
						.card-header {
							padding: .75rem 1.25rem;
							margin-bottom: 0;
							background-color: #f7f7f9;
							border-bottom: 1px solid rgba(0,0,0,.125);
						}
						.card-block {
							-webkit-box-flex: 1;
							-webkit-flex: 1 1 auto;
							-ms-flex: 1 1 auto;
							flex: 1 1 auto;
							padding: 1.25rem;
						}
						.card-footer:last-child {
							border-radius: 0 0 calc(.25rem - 1px) calc(.25rem - 1px);
						}
						.text-muted {
							color: #636c72!important;
						}
						.card-footer {
							padding: .75rem 1.25rem;
							background-color: #f7f7f9;
							border-top: 1px solid rgba(0,0,0,.125);
						}
						.card-title {
							margin-bottom: .75rem;
						}
						p {
							margin-top: 0;
							margin-bottom: 1rem;
						}
						.h4, h4 {
							font-size: 1.5rem;
						}
						
						.btn-primary {
							color: #fff;
							background-color: #0275d8;
							border-color: #0275d8;
						}
						
						.btn {
							display: inline-block;
							font-weight: 400;
							line-height: 1.25;
							text-align: center;
							white-space: nowrap;
							vertical-align: middle;
							-webkit-user-select: none;
							-moz-user-select: none;
							-ms-user-select: none;
							user-select: none;
							border: 1px solid transparent;
							padding: .5rem 1rem;
							font-size: 1rem;
							border-radius: .25rem;
							-webkit-transition: all .2s ease-in-out;
							-o-transition: all .2s ease-in-out;
							transition: all .2s ease-in-out;
						}
						a {
							color: #0275d8;
							text-decoration: none;
						}
						a {
							background-color: transparent;
							-webkit-text-decoration-skip: objects;
						}
					</style></head><body><div class="card text-center"><div class="card-header"><img src="http://d4designers.com/images/logo.png" /></div><div class="card-block">
											<h4 class="card-title">We Inform you</h4>
											<p class="card-text">Your Online booking  appointmennt cancelled</p>
											<a href="http://sreerudraayurveda.com/" class="btn btn-primary">Go Sreerudra Ayurveda Hospital</a>
			  							</div><div class="card-footer text-muted">'.$date.'</div></div>
			
					</body></html>';
			
			
			
					mail($admin_email,$subject,$message,$headers);
					
					
					
//request parameters array
$requestParams = array(
    'user' => 'username',
    'apiKey' => 'dssf645fddfgh565',
    'senderID' => 'CODEXW',
    'receipientno' => 'XXXXXXXXXX',
    'message' => 'Insert sms content'
);

//merge API url and parameters
$apiUrl = "http://api.example.com/http/sendsms?";
foreach($requestParams as $key => $val){
    $apiUrl .= $key.'='.urlencode($val).'&';
}
$apiUrl = rtrim($apiUrl, "&");

//API call
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

curl_exec($ch);
curl_close($ch);


//return payment
header("location:view-booking.php");


?>