<?php

$tocken=$_GET['tocken'];
?>

<html>
<head></head>
<body onLoad="print();">
<p><?php echo $tocken; ?></p>
</body>
</html>